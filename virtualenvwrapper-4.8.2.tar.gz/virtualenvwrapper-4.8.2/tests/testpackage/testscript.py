#!/usr/bin/env python

"""
A test script
"""

print "Hello world"
