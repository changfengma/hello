==========
 Glossary
==========

.. glossary::

  project directory

    Directory associated with a virtualenv, usually located elsewhere
    and containing more permanent development artifacts such as local
    source files, test data, etc. (see :ref:`variable-PROJECT_HOME`)

  template

    Input to :ref:`command-mkproject` that configures the *project
    directory* to contain default files. (see :ref:`plugins`)
