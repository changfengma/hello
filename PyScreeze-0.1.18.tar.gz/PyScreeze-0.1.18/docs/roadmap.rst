.. default-role:: code

=======
Roadmap
=======

- For linux, use gtk and wxpython if available
- Save screenshots to formats besides png